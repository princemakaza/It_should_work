const express = require("express")
const app = express()
app.set("view engine", "ejs")
app.set(express.urlencoded({extended: false}))
app.set(express.json())
const server = require("http").createServer(app)
const io = require("socket.io")(server,{
    cors:{
        origin:'*'
    }
})
const SocketRouter = require('./router/socketRouter')(io)
app.use("/api/v1", SocketRouter)
app.get("/", (req, res)=>{
    res.render('index')
})

io.on("connection", (socket)=>{
    console.log(socket.id)
})
server.listen(3001, ()=>{
    console.log(`The server is running on port: 3001`)
})